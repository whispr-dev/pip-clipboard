#![cfg_attr(
    all(not(debug_assertions), target_os = "windows"),
    windows_subsystem = "windows"
)]

use std::sync::atomic::{AtomicBool, Ordering};
use std::thread;
use std::time::Duration;

use anyhow::Result;
use arboard::{Clipboard, ImageData};
use base64::engine::general_purpose::STANDARD as B64;
use base64::Engine as _;
use image::{ColorType, ImageEncoder};
use once_cell::sync::Lazy;
use parking_lot::Mutex;
use tauri::{
    CustomMenuItem, Manager, SystemTray, SystemTrayEvent, SystemTrayMenu,
    SystemTrayMenuItem, Wry,
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Global state
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

static STATE: Lazy<Mutex<AppState>> = Lazy::new(|| Mutex::new(AppState::default()));

/// Atomic flag so the watcher thread can cheaply skip work while
/// the safe-paste preview overlay is open.
static PREVIEW_ACTIVE: AtomicBool = AtomicBool::new(false);

#[derive(Default)]
struct AppState {
    paused: bool,
    last_fingerprint: Option<u64>,
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Event payload
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

#[derive(Clone, serde::Serialize)]
struct ClipPayload {
    /// `"text"` or `"image"`
    kind: String,
    /// Truncated text or `"Image (WxH)"`
    preview_text: String,
    /// Optional data-URL for image thumbnails
    img_base64: Option<String>,
    /// Byte length of the raw clipboard content (for the size badge)
    raw_len: usize,
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Fingerprinting — cheap change detection via DefaultHasher
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

fn hash_text(s: &str) -> u64 {
    use std::hash::{Hash, Hasher};
    let mut h = std::collections::hash_map::DefaultHasher::new();
    s.hash(&mut h);
    h.finish()
}

fn hash_image(img: &ImageData) -> u64 {
    use std::hash::{Hash, Hasher};
    let mut h = std::collections::hash_map::DefaultHasher::new();
    img.width.hash(&mut h);
    img.height.hash(&mut h);
    let bytes = img.bytes.as_ref();
    let step = bytes.len().saturating_div(64).max(1);
    for i in (0..bytes.len()).step_by(step) {
        bytes[i].hash(&mut h);
    }
    h.finish()
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Image → PNG data-URL
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

fn encode_png_data_url(img: &ImageData, max_dim: u32) -> Result<String> {
    let w = img.width as u32;
    let h = img.height as u32;

    // Cow::to_vec() — no redundant clone when the Cow is already Owned
    let raw = img.bytes.to_vec();
    let mut rgba =
        image::ImageBuffer::<image::Rgba<u8>, _>::from_raw(w, h, raw).unwrap_or_else(|| {
            image::ImageBuffer::from_pixel(w, h, image::Rgba([200, 200, 200, 255]))
        });

    // Down-scale for the preview thumbnail
    if w.max(h) > max_dim {
        let scale = max_dim as f32 / w.max(h) as f32;
        let tw = (w as f32 * scale).round().max(1.0) as u32;
        let th = (h as f32 * scale).round().max(1.0) as u32;
        let dyn_img = image::DynamicImage::ImageRgba8(rgba);
        rgba = dyn_img
            .resize_exact(tw, th, image::imageops::Lanczos3)
            .to_rgba8();
    }

    let mut buf: Vec<u8> = Vec::new();
    let enc = image::codecs::png::PngEncoder::new(&mut buf);
    enc.write_image(rgba.as_raw(), rgba.width(), rgba.height(), ColorType::Rgba8)?;

    Ok(format!("data:image/png;base64,{}", B64.encode(&buf)))
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Read current clipboard into a payload
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

fn read_clipboard(max_text: usize, max_img_dim: u32) -> Option<ClipPayload> {
    let mut clip = Clipboard::new().ok()?;

    // Text first
    if let Ok(text) = clip.get_text() {
        if !text.is_empty() {
            let raw_len = text.len();
            let mut preview = text;
            if preview.len() > max_text {
                preview.truncate(max_text);
                preview.push_str("…");
            }
            return Some(ClipPayload {
                kind: "text".into(),
                preview_text: preview,
                img_base64: None,
                raw_len,
            });
        }
    }

    // Then image
    if let Ok(img) = clip.get_image() {
        let iw = img.width;
        let ih = img.height;
        let raw_len = img.bytes.len();
        let b64 = encode_png_data_url(&img, max_img_dim).ok();
        return Some(ClipPayload {
            kind: "image".into(),
            preview_text: format!("Image ({}×{})", iw, ih),
            img_base64: b64,
            raw_len,
        });
    }

    None
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Keystroke injection via enigo
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

fn do_paste_injection() {
    use enigo::{Direction, Enigo, Key, Keyboard, Settings};

    let Ok(mut enigo) = Enigo::new(&Settings::default()) else {
        eprintln!("[pip-clip] failed to create enigo instance");
        return;
    };

    #[cfg(target_os = "macos")]
    let modifier = Key::Meta;
    #[cfg(not(target_os = "macos"))]
    let modifier = Key::Control;

    let _ = enigo.key(modifier, Direction::Press);
    let _ = enigo.key(Key::Unicode('v'), Direction::Click);
    let _ = enigo.key(modifier, Direction::Release);
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Tauri commands (invoked from the webview)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/// User confirmed the paste — hide the overlay, then inject Ctrl+V
/// into whatever app was previously focused.
#[tauri::command]
fn confirm_paste(window: tauri::Window) -> Result<(), String> {
    PREVIEW_ACTIVE.store(false, Ordering::SeqCst);
    window.hide().map_err(|e| e.to_string())?;

    // Spawn off-thread so we don't block the webview.
    // The 150 ms delay lets the OS return focus to the previous app.
    thread::spawn(|| {
        thread::sleep(Duration::from_millis(150));
        do_paste_injection();
    });

    Ok(())
}

/// User cancelled — just hide, no paste.
#[tauri::command]
fn cancel_paste(window: tauri::Window) -> Result<(), String> {
    PREVIEW_ACTIVE.store(false, Ordering::SeqCst);
    window.hide().map_err(|e| e.to_string())?;
    Ok(())
}

/// On-demand clipboard read (UI can call this if it missed the event).
#[tauri::command]
fn get_clipboard_now() -> Option<ClipPayload> {
    read_clipboard(2000, 640)
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Global hotkey — Ctrl+Shift+V  →  safe-paste preview
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

fn register_safe_paste(app: &tauri::AppHandle<Wry>) -> Result<()> {
    let mut gsm = app.global_shortcut_manager();

    #[cfg(target_os = "macos")]
    let accel = "Command+Shift+V";
    #[cfg(not(target_os = "macos"))]
    let accel = "Ctrl+Shift+V";

    if gsm.is_registered(accel)? {
        gsm.unregister(accel)?;
    }

    let handle = app.clone();
    gsm.register(accel, move || {
        let payload = read_clipboard(2000, 640);

        if let Some(w) = handle.get_window("hud") {
            // Position to bottom-right, respecting HiDPI scale factor
            if let Ok(Some(monitor)) = w.current_monitor() {
                let sz = monitor.size();
                let sf = monitor.scale_factor();
                let win_w = 440.0_f64;
                let win_h = 300.0_f64;
                let margin = 24.0_f64;
                let x = (sz.width as f64 / sf - win_w - margin).max(0.0);
                let y = (sz.height as f64 / sf - win_h - margin).max(0.0);
                let _ = w.set_position(tauri::Position::Logical(tauri::LogicalPosition {
                    x,
                    y,
                }));
                let _ = w.set_size(tauri::Size::Logical(tauri::LogicalSize {
                    width: win_w,
                    height: win_h,
                }));
            }

            let _ = w.show();
            let _ = w.set_always_on_top(true);
            let _ = w.set_focus();
            PREVIEW_ACTIVE.store(true, Ordering::SeqCst);
            let _ = w.emit("show_preview", &payload);
        }
    })?;

    Ok(())
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  System tray
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

fn build_tray() -> SystemTray {
    let toggle = CustomMenuItem::new("toggle_hud", "Toggle HUD");
    let pause = CustomMenuItem::new("pause", "Pause Monitoring");
    let sep = SystemTrayMenuItem::Separator;
    let quit = CustomMenuItem::new("quit", "Quit pip-clip");

    let menu = SystemTrayMenu::new()
        .add_item(toggle)
        .add_item(pause)
        .add_native_item(sep)
        .add_item(quit);

    SystemTray::new().with_menu(menu)
}

fn handle_tray_event(app: &tauri::AppHandle, event: SystemTrayEvent) {
    if let SystemTrayEvent::MenuItemClick { id, .. } = event {
        match id.as_str() {
            "toggle_hud" => {
                if let Some(w) = app.get_window("hud") {
                    if w.is_visible().unwrap_or(true) {
                        let _ = w.hide();
                    } else {
                        let _ = w.show();
                        let _ = w.set_focus();
                    }
                }
            }
            "pause" => {
                let mut st = STATE.lock();
                st.paused = !st.paused;
                let label = if st.paused {
                    "Resume Monitoring"
                } else {
                    "Pause Monitoring"
                };
                let item = app.tray_handle().get_item(&id);
                let _ = item.set_title(label);
            }
            "quit" => std::process::exit(0),
            _ => {}
        }
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Passive clipboard watcher (ambient HUD notifications)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

fn spawn_watcher(app: tauri::AppHandle<Wry>) {
    thread::spawn(move || {
        let mut clip = match Clipboard::new() {
            Ok(c) => c,
            Err(e) => {
                eprintln!("[pip-clip] clipboard init failed: {e}");
                return;
            }
        };

        loop {
            // Don't poll while paused or while the confirm overlay is open
            {
                let paused = STATE.lock().paused;
                if paused || PREVIEW_ACTIVE.load(Ordering::Relaxed) {
                    thread::sleep(Duration::from_millis(400));
                    continue;
                }
            }

            let mut changed_payload: Option<ClipPayload> = None;

            if let Ok(text) = clip.get_text() {
                if !text.is_empty() {
                    let fp = hash_text(&text);
                    let mut st = STATE.lock();
                    if st.last_fingerprint != Some(fp) {
                        st.last_fingerprint = Some(fp);
                        let raw_len = text.len();
                        let mut preview = text;
                        if preview.len() > 300 {
                            preview.truncate(300);
                            preview.push_str("…");
                        }
                        changed_payload = Some(ClipPayload {
                            kind: "text".into(),
                            preview_text: preview,
                            img_base64: None,
                            raw_len,
                        });
                    }
                }
            } else if let Ok(img) = clip.get_image() {
                let fp = hash_image(&img);
                let mut st = STATE.lock();
                if st.last_fingerprint != Some(fp) {
                    st.last_fingerprint = Some(fp);
                    let iw = img.width;
                    let ih = img.height;
                    let raw_len = img.bytes.len();
                    let b64 = encode_png_data_url(&img, 320).ok();
                    changed_payload = Some(ClipPayload {
                        kind: "image".into(),
                        preview_text: format!("Image ({}×{})", iw, ih),
                        img_base64: b64,
                        raw_len,
                    });
                }
            }

            if let Some(p) = changed_payload {
                let _ = app.emit_all("clipboard_changed", p);
            }

            thread::sleep(Duration::from_millis(250));
        }
    });
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Entry point
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

fn main() {
    tauri::Builder::default()
        .setup(|app| {
            // Start hidden; will appear on first clipboard change or hotkey
            if let Some(w) = app.get_window("hud") {
                let _ = w.hide();
            }
            register_safe_paste(&app.handle()).ok();
            spawn_watcher(app.handle());
            Ok(())
        })
        .system_tray(build_tray())
        .on_system_tray_event(handle_tray_event)
        .invoke_handler(tauri::generate_handler![
            confirm_paste,
            cancel_paste,
            get_clipboard_now
        ])
        .run(tauri::generate_context!())
        .expect("error running pip-clip-osd");
}
